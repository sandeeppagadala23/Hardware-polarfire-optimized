module input_buffer (
    input clk,
    input rst,
    input sample_valid,
    input sample_ready,
    input signed [15:0] sample_in,
    output reg sample_out_valid,
    output reg signed [15:0] sample_out,
    output full,
    output empty,
    output reg overflow
);

parameter DATA_WIDTH = 16;
parameter DEPTH = 32;
parameter ADDR_WIDTH = 5;

reg signed [DATA_WIDTH-1:0] mem [0:DEPTH-1];
reg [ADDR_WIDTH-1:0] wr_ptr;
reg [ADDR_WIDTH-1:0] rd_ptr;
reg [ADDR_WIDTH:0] count;
wire do_write;
wire do_read;

assign full = (count == DEPTH);
assign empty = (count == 0);
assign do_write = sample_valid && !full;
assign do_read = sample_ready && !empty;

/*
Purpose: FIFO input buffer for continuous Q8.8 ECG samples.
Architecture: Circular RAM with independent read and write pointers.
Ports: sample_valid/sample_in write samples; sample_ready drains toward the window stage.
Timing: Registered output with one-cycle read latency.
Pipeline stage: Input decoupling and backpressure absorption.
Data flow: ECG stream -> FIFO -> sliding_window_1d.
Algorithm: Store accepted samples and replay them in arrival order.
Expected latency: One clock from read enable to sample_out_valid.
Resource estimate: DEPTH x DATA_WIDTH flip-flops or distributed RAM.
*/
always @(posedge clk) begin
    if (rst) begin
        wr_ptr <= {ADDR_WIDTH{1'b0}};
        rd_ptr <= {ADDR_WIDTH{1'b0}};
        count <= {(ADDR_WIDTH+1){1'b0}};
        sample_out_valid <= 1'b0;
        sample_out <= {DATA_WIDTH{1'b0}};
        overflow <= 1'b0;
    end else begin
        sample_out_valid <= 1'b0;
        overflow <= sample_valid && full;

        if (do_write) begin
            mem[wr_ptr] <= sample_in;
            wr_ptr <= wr_ptr + 1'b1;
        end

        if (do_read) begin
            sample_out <= mem[rd_ptr];
            rd_ptr <= rd_ptr + 1'b1;
            sample_out_valid <= 1'b1;
        end

        case ({do_write, do_read})
            2'b10: count <= count + 1'b1;
            2'b01: count <= count - 1'b1;
            default: count <= count;
        endcase
    end
end

endmodule
