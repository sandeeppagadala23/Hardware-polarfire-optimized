module classifier (
    input clk,
    input rst,
    input valid_in,
    input signed [31:0] score_normal,
    input signed [31:0] score_arrhythmia,
    output reg valid_out,
    output reg class_id,
    output reg signed [31:0] confidence
);

parameter DATA_WIDTH = 32;

/*
Purpose: Binary arrhythmia classifier.
Architecture: Registered two-score comparator.
Ports: class_id is 0 for normal and 1 for arrhythmia.
Timing: One clock from valid_in to valid_out.
Pipeline stage: Classification.
Data flow: fully_connected -> classifier -> output_buffer.
Algorithm: Choose arrhythmia when score_arrhythmia is greater than score_normal.
Expected latency: One clock.
Resource estimate: One signed comparator and output registers.
*/
always @(posedge clk) begin
    if (rst) begin
        valid_out <= 1'b0;
        class_id <= 1'b0;
        confidence <= {DATA_WIDTH{1'b0}};
    end else begin
        valid_out <= valid_in;
        if (valid_in) begin
            if (score_arrhythmia > score_normal) begin
                class_id <= 1'b1;
                confidence <= score_arrhythmia;
            end else begin
                class_id <= 1'b0;
                confidence <= score_normal;
            end
        end
    end
end

endmodule
