module maxpool1d (
    input clk,
    input rst,
    input valid_in,
    input signed [31:0] data_in,
    output reg valid_out,
    output reg signed [31:0] data_out
);

parameter DATA_WIDTH = 32;
parameter POOL_SIZE = 2;

reg signed [DATA_WIDTH-1:0] current_max;
reg [3:0] pool_count;
wire signed [DATA_WIDTH-1:0] next_max;

assign next_max = (data_in > current_max) ? data_in : current_max;

/*
Purpose: 1D max-pooling stage for ECG CNN features.
Architecture: Streaming reducer over POOL_SIZE consecutive valid samples.
Ports: valid_in/data_in enter the pool; valid_out/data_out emit pooled maxima.
Timing: One output every POOL_SIZE valid inputs.
Pipeline stage: Temporal downsampling.
Data flow: relu -> maxpool1d -> flatten.
Algorithm: Track the maximum value in each non-overlapping pool group.
Expected latency: POOL_SIZE clocks for the first pooled output.
Resource estimate: One comparator, one counter, one data register.
*/
always @(posedge clk) begin
    if (rst) begin
        current_max <= {DATA_WIDTH{1'b0}};
        pool_count <= 4'd0;
        valid_out <= 1'b0;
        data_out <= {DATA_WIDTH{1'b0}};
    end else begin
        valid_out <= 1'b0;
        if (valid_in) begin
            if (pool_count == 4'd0) begin
                current_max <= data_in;
                if (POOL_SIZE == 1) begin
                    data_out <= data_in;
                    valid_out <= 1'b1;
                    pool_count <= 4'd0;
                end else begin
                    pool_count <= 4'd1;
                end
            end else if (pool_count == (POOL_SIZE - 1)) begin
                data_out <= next_max;
                current_max <= {DATA_WIDTH{1'b0}};
                pool_count <= 4'd0;
                valid_out <= 1'b1;
            end else begin
                current_max <= next_max;
                pool_count <= pool_count + 1'b1;
            end
        end
    end
end

endmodule
