module flatten (
    input clk,
    input rst,
    input valid_in,
    input signed [31:0] data_in,
    output reg valid_out,
    output reg signed [127:0] feature_vector
);

parameter DATA_WIDTH = 32;
parameter FEATURE_COUNT = 4;

reg signed [FEATURE_COUNT*DATA_WIDTH-1:0] feature_store;
reg signed [FEATURE_COUNT*DATA_WIDTH-1:0] next_vector;
reg [3:0] feature_count_reg;
integer i;

/*
Purpose: Packs pooled streaming features into a dense-layer feature vector.
Architecture: Sequential collector with fixed FEATURE_COUNT frame length.
Ports: valid_in/data_in accept pooled features; feature_vector emits packed features.
Timing: Emits valid_out when FEATURE_COUNT samples have been collected.
Pipeline stage: Flatten/frame formation.
Data flow: maxpool1d -> flatten -> fully_connected.
Algorithm: Store each pooled feature in order and publish a vector at frame completion.
Expected latency: FEATURE_COUNT pooled outputs.
Resource estimate: FEATURE_COUNT x DATA_WIDTH registers plus a small counter.
*/
always @(*) begin
    next_vector = feature_store;
    next_vector[feature_count_reg*DATA_WIDTH +: DATA_WIDTH] = data_in;
end

always @(posedge clk) begin
    if (rst) begin
        feature_store <= {FEATURE_COUNT*DATA_WIDTH{1'b0}};
        feature_vector <= {FEATURE_COUNT*DATA_WIDTH{1'b0}};
        feature_count_reg <= 4'd0;
        valid_out <= 1'b0;
    end else begin
        valid_out <= 1'b0;
        if (valid_in) begin
            feature_store <= next_vector;
            if (feature_count_reg == (FEATURE_COUNT - 1)) begin
                feature_vector <= next_vector;
                feature_count_reg <= 4'd0;
                valid_out <= 1'b1;
            end else begin
                feature_count_reg <= feature_count_reg + 1'b1;
            end
        end
    end
end

endmodule
