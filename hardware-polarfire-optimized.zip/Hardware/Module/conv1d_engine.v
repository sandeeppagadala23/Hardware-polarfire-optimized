module conv1d_engine (
    input clk,
    input rst,
    input window_valid,
    input signed [79:0] window_in,
    output reg conv_valid,
    output reg signed [31:0] conv_out
);

parameter DATA_WIDTH = 16;
parameter KERNEL_SIZE = 5;
parameter ACC_WIDTH = 32;
parameter FRAC_BITS = 8;
parameter WEIGHT_COUNT = 16;
parameter WEIGHT_BASE = 0;
parameter WEIGHTS_FILE = "weights.mem";

// PolarFire-friendly weight store: explicitly sized, single read port,
// loaded once at elaboration via $readmemh. syn_romstyle guides Synplify
// Pro (Libero SoC's synthesis engine) to map this to a dedicated
// PolarFire uSRAM/LSRAM block instead of scattered fabric flip-flops.
// At WEIGHT_COUNT=16 x 16 bits the mapper may still choose distributed
// logic since it is cheaper than a full LSRAM row for this size -- that
// is expected and fine; the attribute matters once WEIGHT_COUNT grows
// (e.g. deeper kernels or more output channels).
(* syn_romstyle = "block_rom" *)
reg signed [DATA_WIDTH-1:0] weights [0:WEIGHT_COUNT-1];

// Pipeline stage 1: one registered scaled product per tap. Each
// (sample * weight) multiply is a standalone a*b pattern that Synplify
// maps to its own PF_MACC (PolarFire Math/DSP) block; registering the
// product here uses the PF_MACC's own output register, so this costs no
// extra fabric flip-flops.
reg signed [ACC_WIDTH-1:0] product_reg [0:KERNEL_SIZE-1];
reg signed [ACC_WIDTH-1:0] bias_reg;
reg valid_stage1;
integer i;
integer j;

// Pipeline stage 2: combinational reduction of the KERNEL_SIZE registered
// products (plus bias), registered once into conv_out. This is a short
// adder-only tree (no multiplies), which is the actual critical-path win:
// the old design evaluated 5 multiplies AND a 6-input add chain in one
// combinational block before the single output register.
reg signed [ACC_WIDTH-1:0] sum_comb;

/*
Purpose: Streaming 1D convolution engine for ECG time-series windows.
Architecture: 2-stage pipelined MAC array. Stage 1 registers KERNEL_SIZE
  independent Q8.8 products (each inferred as a PolarFire PF_MACC block).
  Stage 2 registers the sum of those products plus bias through a short
  combinational adder tree. This breaks the original single-cycle
  "5 multiplies then 6-input add" critical path into two shorter stages
  for PolarFire fabric timing closure, without adding any stall cycles.
Ports: window_in contains KERNEL_SIZE Q8.8 samples; conv_out is a signed 32-bit Q24.8 value.
Timing: Two clocks from window_valid to conv_valid (was one clock before
  this pipelining pass). Fully pipelined: a new window_valid can be
  accepted every clock, so streaming throughput is unchanged at one
  window per clock -- only the fixed pipeline latency grew by one cycle.
Pipeline stage: 1D convolution, stage 1 of 2 (multiply/register) then
  stage 2 of 2 (reduce/register).
Data flow: sliding_window_1d -> conv1d_engine -> relu.
Algorithm: bias + sum((sample[i] * weight[i]) >>> 8), with weights loaded
  by $readmemh. Grouping of the sum differs from the original single-step
  version but two's-complement addition modulo 2^32 is associative, so the
  registered result is bit-identical to the original combinational result.
Expected latency: Two clocks.
Resource estimate: KERNEL_SIZE PF_MACC-inferred multiply-accumulate blocks
  (stage 1, each with its own output register), one 6-input registered
  adder for bias + reduction (stage 2).
*/
initial begin
    $readmemh(WEIGHTS_FILE, weights);
end

// Stage 1: register the per-tap scaled products and the bias.
always @(posedge clk) begin
    if (rst) begin
        valid_stage1 <= 1'b0;
        bias_reg <= {ACC_WIDTH{1'b0}};
        for (i = 0; i < KERNEL_SIZE; i = i + 1) begin
            product_reg[i] <= {ACC_WIDTH{1'b0}};
        end
    end else begin
        valid_stage1 <= window_valid;
        if (window_valid) begin
            bias_reg <= {{(ACC_WIDTH-DATA_WIDTH){weights[WEIGHT_BASE+KERNEL_SIZE][DATA_WIDTH-1]}}, weights[WEIGHT_BASE+KERNEL_SIZE]};
            for (i = 0; i < KERNEL_SIZE; i = i + 1) begin
                product_reg[i] <= (window_in[i*DATA_WIDTH +: DATA_WIDTH] * weights[WEIGHT_BASE+i]) >>> FRAC_BITS;
            end
        end
    end
end

// Combinational stage-2 reduction: adders only, short critical path.
always @(*) begin
    sum_comb = bias_reg;
    for (j = 0; j < KERNEL_SIZE; j = j + 1) begin
        sum_comb = sum_comb + product_reg[j];
    end
end

// Stage 2: register the reduced sum as conv_out.
always @(posedge clk) begin
    if (rst) begin
        conv_valid <= 1'b0;
        conv_out <= {ACC_WIDTH{1'b0}};
    end else begin
        conv_valid <= valid_stage1;
        if (valid_stage1) begin
            conv_out <= sum_comb;
        end
    end
end

endmodule
