module output_buffer (
    input clk,
    input rst,
    input valid_in,
    input output_ready,
    input class_in,
    input signed [31:0] confidence_in,
    output reg valid_out,
    output reg class_out,
    output reg signed [31:0] confidence_out
);

/*
Purpose: Holds the latest binary classification result until consumed.
Architecture: One-entry valid register.
Ports: output_ready clears valid_out after the downstream side accepts the result.
Timing: Classification result is visible one clock after valid_in.
Pipeline stage: Output buffering.
Data flow: classifier -> output_buffer -> host or medical-device output pins.
Algorithm: Latch new result on valid_in and hold until output_ready.
Expected latency: One clock.
Resource estimate: One class register, one confidence register, one valid bit.
*/
always @(posedge clk) begin
    if (rst) begin
        valid_out <= 1'b0;
        class_out <= 1'b0;
        confidence_out <= 32'sd0;
    end else begin
        if (valid_in) begin
            valid_out <= 1'b1;
            class_out <= class_in;
            confidence_out <= confidence_in;
        end else if (output_ready) begin
            valid_out <= 1'b0;
        end
    end
end

endmodule
