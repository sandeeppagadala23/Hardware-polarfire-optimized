module top_axi_wrapper (
    // ---- Fabric-side clock/reset (drives the existing `top` core) ----
    input               clk,
    input               rst,

    // ---- AXI4-Lite control/status slave (from the MSS RISC-V, e.g. via
    //      the AXI switch / CoreAXI4-to-fabric bridge). Assumed to run on
    //      the SAME clk as above for this sketch -- see CDC note below. ----
    input               s_axi_awvalid,
    output              s_axi_awready,
    input       [7:0]   s_axi_awaddr,
    input               s_axi_wvalid,
    output              s_axi_wready,
    input       [31:0]  s_axi_wdata,
    input       [3:0]   s_axi_wstrb,
    output              s_axi_bvalid,
    input               s_axi_bready,
    output      [1:0]   s_axi_bresp,
    input               s_axi_arvalid,
    output              s_axi_arready,
    input       [7:0]   s_axi_araddr,
    output              s_axi_rvalid,
    input               s_axi_rready,
    output      [31:0]  s_axi_rdata,
    output      [1:0]   s_axi_rresp,

    // ---- AXI4-Stream slave: ECG samples in ----
    input               s_axis_tvalid,
    output              s_axis_tready,
    input       [15:0]  s_axis_tdata,

    // ---- AXI4-Stream master: classification result out ----
    output              m_axis_tvalid,
    input               m_axis_tready,
    output      [63:0]  m_axis_tdata   // {31'b0, confidence_out[31:0], 31'b0, class_out}
);

/*
Purpose: Thin AXI4-Lite (control/status) + AXI4-Stream (samples in /
  result out) wrapper so the MSS RISC-V subsystem on PolarFire SoC can
  drive the existing `top` core over standard AXI interconnect, without
  modifying `top.v` itself -- `top` stays reusable standalone (e.g. for a
  future non-AXI integration or a different SoC).
Architecture: `top` is instantiated unmodified. AXI4-Lite exposes a CONTROL
  register (bit0 = start, bit1 = output_ready) and a STATUS register
  (bit0 = done, bit1 = fifo_full, bit2 = output_valid, bit3 = class_out).
  AXI4-Stream slave feeds ecg_valid/ecg_sample and backpressures with
  s_axis_tready = start && !fifo_full. AXI4-Stream master exposes
  output_valid/class_out/confidence_out packed into one 64-bit beat.
Ports: see above; `top`'s own ports are unchanged (see top.v).
Timing: This wrapper is purely combinational glue plus the two tiny AXI4-
  Lite response registers below -- it adds no pipeline stages to the
  streaming datapath inside `top`.
Pipeline stage: MSS <-> fabric integration boundary.
Data flow: MSS (AXI4-Lite writes/reads) -> CONTROL/STATUS registers ->
  top.start/top.output_ready. MSS or a DMA engine (AXI4-Stream) ->
  s_axis -> top.ecg_valid/top.ecg_sample. top.output_valid/class_out/
  confidence_out -> m_axis -> MSS or a DMA engine.
Algorithm: Direct signal mapping; no reformatting of the underlying
  Q8.8 / Q24.8 fixed-point values.
Expected latency: Zero added cycles beyond `top`'s own latency (see
  top.v and README.md Latency Analysis) plus whatever the AXI
  interconnect itself adds.
Resource estimate: Two 32-bit AXI4-Lite registers (CONTROL write, STATUS
  read-back), small response-channel FSMs, no PF_MACC/RAM usage of its own.

*** CLOCK-DOMAIN-CROSSING NOTE (read before integrating) ***
This sketch assumes the AXI4-Lite and AXI4-Stream interfaces are on the
same clk as `top`'s fabric clock. On a real PolarFire SoC design the MSS
AXI switch clock and the fabric `clk` driving `top` are very likely
DIFFERENT clock domains. Do not add ad-hoc single-bit synchronizers to
the AXI4-Stream *data* buses (s_axis_tdata / m_axis_tdata are multi-bit
buses and need a real CDC FIFO, not a synchronizer chain). If the MSS and
fabric clocks differ:
  - Insert a CoreAXI4-based (or equivalent Libero Catalog) AXI4-Stream
    async FIFO between the MSS and this wrapper's s_axis_*/m_axis_*
    ports, sized for the sample rate.
  - For the AXI4-Lite control/status path, either run the AXI4-Lite
    slave logic on the MSS clock and pass CONTROL/STATUS through a
    2-flop synchronizer per bit (safe here since each bit is a level,
    not a multi-cycle pulse), or use a small CDC handshake (req/ack) if
    you convert `start`/`output_ready` into pulses.
  - `rst` must be a synchronous reset within each clock domain; if the
    MSS reset and fabric reset are not already the same reset tree,
    generate a synchronized reset per domain (e.g. via CoreResetP) rather
    than driving `rst` directly from an MSS-domain signal.
*/

// ---- AXI4-Lite register map ----
localparam ADDR_CONTROL = 8'h00; // [0]=start [1]=output_ready
localparam ADDR_STATUS  = 8'h04; // [0]=done  [1]=fifo_full [2]=output_valid [3]=class_out

reg        reg_start;
reg        reg_output_ready;

wire       top_output_valid;
wire       top_class_out;
wire signed [31:0] top_confidence_out;
wire       top_fifo_full;
wire       top_done;

// -- AXI4-Lite write channel: single always-ready register write --
reg  aw_hs, w_hs;
assign s_axi_awready = !aw_hs;
assign s_axi_wready  = !w_hs;

reg  bvalid_reg;
reg [7:0] awaddr_latched;

always @(posedge clk) begin
    if (rst) begin
        aw_hs <= 1'b0;
        w_hs <= 1'b0;
        bvalid_reg <= 1'b0;
        reg_start <= 1'b0;
        reg_output_ready <= 1'b0;
        awaddr_latched <= 8'h00;
    end else begin
        if (s_axi_awvalid && s_axi_awready) begin
            aw_hs <= 1'b1;
            awaddr_latched <= s_axi_awaddr;
        end
        if (s_axi_wvalid && s_axi_wready) begin
            w_hs <= 1'b1;
        end
        if (aw_hs && w_hs && !bvalid_reg) begin
            if (awaddr_latched == ADDR_CONTROL) begin
                if (s_axi_wstrb[0]) begin
                    reg_start        <= s_axi_wdata[0];
                    reg_output_ready <= s_axi_wdata[1];
                end
            end
            bvalid_reg <= 1'b1;
            aw_hs <= 1'b0;
            w_hs <= 1'b0;
        end
        if (bvalid_reg && s_axi_bready) begin
            bvalid_reg <= 1'b0;
        end
    end
end

assign s_axi_bvalid = bvalid_reg;
assign s_axi_bresp  = 2'b00; // OKAY

// -- AXI4-Lite read channel: single always-ready register read --
reg        ar_hs;
reg        rvalid_reg;
reg [7:0]  araddr_latched;
reg [31:0] rdata_reg;

assign s_axi_arready = !ar_hs;

always @(posedge clk) begin
    if (rst) begin
        ar_hs <= 1'b0;
        rvalid_reg <= 1'b0;
        araddr_latched <= 8'h00;
        rdata_reg <= 32'h0;
    end else begin
        if (s_axi_arvalid && s_axi_arready) begin
            ar_hs <= 1'b1;
            araddr_latched <= s_axi_araddr;
        end
        if (ar_hs && !rvalid_reg) begin
            case (araddr_latched)
                ADDR_CONTROL: rdata_reg <= {30'b0, reg_output_ready, reg_start};
                ADDR_STATUS:  rdata_reg <= {28'b0, top_class_out, top_output_valid, top_fifo_full, top_done};
                default:      rdata_reg <= 32'h0;
            endcase
            rvalid_reg <= 1'b1;
            ar_hs <= 1'b0;
        end
        if (rvalid_reg && s_axi_rready) begin
            rvalid_reg <= 1'b0;
        end
    end
end

assign s_axi_rvalid = rvalid_reg;
assign s_axi_rdata  = rdata_reg;
assign s_axi_rresp  = 2'b00; // OKAY

// -- AXI4-Stream slave: ECG samples in --
// top's input_buffer FIFO already provides backpressure via fifo_full;
// gate acceptance on reg_start so samples are only pulled in while the
// core is armed to stream.
assign s_axis_tready = reg_start && !top_fifo_full;

// -- AXI4-Stream master: classification result out --
// class_out and confidence_out are packed into one 64-bit beat so a
// single-beat AXI4-Stream transfer carries the full result; unused bits
// are zero. output_ready pulses for one cycle on each accepted beat so
// output_buffer.v releases its held result exactly once per read.
assign m_axis_tvalid = top_output_valid;
assign m_axis_tdata  = {31'b0, top_confidence_out, 31'b0, top_class_out};

wire top_output_ready = reg_output_ready || (m_axis_tvalid && m_axis_tready);

top u_top (
    .clk(clk),
    .rst(rst),
    .start(reg_start),
    .ecg_valid(s_axis_tvalid && s_axis_tready),
    .ecg_sample(s_axis_tdata),
    .output_ready(top_output_ready),
    .output_valid(top_output_valid),
    .class_out(top_class_out),
    .confidence_out(top_confidence_out),
    .fifo_full(top_fifo_full),
    .done(top_done)
);

endmodule
