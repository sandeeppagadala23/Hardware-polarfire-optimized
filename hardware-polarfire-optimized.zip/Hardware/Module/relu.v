module relu (
    input clk,
    input rst,
    input valid_in,
    input signed [31:0] data_in,
    output reg valid_out,
    output reg signed [31:0] data_out
);

parameter DATA_WIDTH = 32;

/*
Purpose: Rectified linear activation for CNN feature maps.
Architecture: Registered signed comparator and mux.
Ports: data_in is signed; negative values clamp to zero.
Timing: One clock from valid_in to valid_out.
Pipeline stage: Activation.
Data flow: conv1d_engine -> relu -> maxpool1d.
Algorithm: data_out = max(data_in, 0).
Expected latency: One clock.
Resource estimate: One comparator and one register bank.
*/
always @(posedge clk) begin
    if (rst) begin
        valid_out <= 1'b0;
        data_out <= {DATA_WIDTH{1'b0}};
    end else begin
        valid_out <= valid_in;
        if (valid_in) begin
            if (data_in < 0) begin
                data_out <= {DATA_WIDTH{1'b0}};
            end else begin
                data_out <= data_in;
            end
        end
    end
end

endmodule
