module top (
    input clk,
    input rst,
    input start,
    input ecg_valid,
    input signed [15:0] ecg_sample,
    input output_ready,
    output output_valid,
    output class_out,
    output signed [31:0] confidence_out,
    output fifo_full,
    output done
);

parameter SAMPLE_WIDTH = 16;
parameter KERNEL_SIZE = 5;
parameter FEATURE_COUNT = 4;

wire fifo_empty;
wire fifo_overflow;
wire fifo_sample_valid;
wire signed [15:0] fifo_sample;
wire window_valid;
wire signed [79:0] window_data;
wire conv_valid;
wire signed [31:0] conv_data;
wire relu_valid;
wire signed [31:0] relu_data;
wire pool_valid;
wire signed [31:0] pool_data;
wire flatten_valid;
wire signed [127:0] feature_vector;
wire fc_valid;
wire signed [31:0] score_normal;
wire signed [31:0] score_arrhythmia;
wire class_valid;
wire class_id;
wire signed [31:0] confidence;
wire input_enable;
wire window_enable;
wire conv_enable;
wire relu_enable;
wire pool_enable;
wire flatten_enable;
wire fc_enable;
wire classify_enable;
wire output_enable;
wire [3:0] controller_state;

/*
Purpose: Top-level ECG 1D CNN streaming accelerator.
Architecture: FIFO -> sliding window -> 1D conv -> ReLU -> MaxPool1D -> Flatten -> FC -> Classifier -> output buffer.
Ports: ecg_valid/ecg_sample carry Q8.8 ECG samples; output_valid/class_out report binary inference.
Timing: Fully registered stream path after each compute stage.
Pipeline stage: System integration.
Data flow: Continuous ECG samples become framed feature vectors and binary arrhythmia results.
Algorithm: Streaming 1D CNN with kernel size 5, pool size 2, four-feature dense layer, and binary classifier.
Expected latency: About 19 clocks to first output with default parameters after FIFO read
  begins (was 17 before the PolarFire optimization pass; conv1d_engine.v and
  fully_connected.v each moved from a 1-cycle to a 2-cycle pipeline to shorten the
  critical path, adding one clock apiece -- see README.md Latency Analysis).
Resource estimate: FIFO storage, five conv PF_MACC blocks, pooling comparator, eight FC
  PF_MACC blocks, control registers. Multipliers are PolarFire Math/DSP (PF_MACC)
  inferred blocks rather than fabric LUT multipliers -- see mac.v, conv1d_engine.v,
  and fully_connected.v headers.
*/
controller u_controller (
    .clk(clk),
    .rst(rst),
    .start(start),
    .input_valid(fifo_sample_valid),
    .window_valid(window_valid),
    .conv_valid(conv_valid),
    .relu_valid(relu_valid),
    .pool_valid(pool_valid),
    .flatten_valid(flatten_valid),
    .fc_valid(fc_valid),
    .class_valid(class_valid),
    .output_ready(output_ready),
    .input_enable(input_enable),
    .window_enable(window_enable),
    .conv_enable(conv_enable),
    .relu_enable(relu_enable),
    .pool_enable(pool_enable),
    .flatten_enable(flatten_enable),
    .fc_enable(fc_enable),
    .classify_enable(classify_enable),
    .output_enable(output_enable),
    .done(done),
    .state(controller_state)
);

input_buffer u_input_buffer (
    .clk(clk),
    .rst(rst),
    .sample_valid(ecg_valid),
    .sample_ready(start && !fifo_empty),
    .sample_in(ecg_sample),
    .sample_out_valid(fifo_sample_valid),
    .sample_out(fifo_sample),
    .full(fifo_full),
    .empty(fifo_empty),
    .overflow(fifo_overflow)
);

sliding_window_1d u_sliding_window_1d (
    .clk(clk),
    .rst(rst),
    .sample_valid(fifo_sample_valid),
    .sample_in(fifo_sample),
    .window_valid(window_valid),
    .window_out(window_data)
);

conv1d_engine u_conv1d_engine (
    .clk(clk),
    .rst(rst),
    .window_valid(window_valid),
    .window_in(window_data),
    .conv_valid(conv_valid),
    .conv_out(conv_data)
);

relu u_relu (
    .clk(clk),
    .rst(rst),
    .valid_in(conv_valid),
    .data_in(conv_data),
    .valid_out(relu_valid),
    .data_out(relu_data)
);

maxpool1d u_maxpool1d (
    .clk(clk),
    .rst(rst),
    .valid_in(relu_valid),
    .data_in(relu_data),
    .valid_out(pool_valid),
    .data_out(pool_data)
);

flatten u_flatten (
    .clk(clk),
    .rst(rst),
    .valid_in(pool_valid),
    .data_in(pool_data),
    .valid_out(flatten_valid),
    .feature_vector(feature_vector)
);

fully_connected u_fully_connected (
    .clk(clk),
    .rst(rst),
    .valid_in(flatten_valid),
    .feature_vector(feature_vector),
    .valid_out(fc_valid),
    .score_normal(score_normal),
    .score_arrhythmia(score_arrhythmia)
);

classifier u_classifier (
    .clk(clk),
    .rst(rst),
    .valid_in(fc_valid),
    .score_normal(score_normal),
    .score_arrhythmia(score_arrhythmia),
    .valid_out(class_valid),
    .class_id(class_id),
    .confidence(confidence)
);

output_buffer u_output_buffer (
    .clk(clk),
    .rst(rst),
    .valid_in(class_valid),
    .output_ready(output_ready),
    .class_in(class_id),
    .confidence_in(confidence),
    .valid_out(output_valid),
    .class_out(class_out),
    .confidence_out(confidence_out)
);

endmodule
