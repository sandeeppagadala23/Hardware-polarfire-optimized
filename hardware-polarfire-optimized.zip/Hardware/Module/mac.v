module mac (
    input clk,
    input rst,
    input valid_in,
    input signed [15:0] data_in,
    input signed [15:0] weight,
    input signed [31:0] acc_in,
    output reg valid_out,
    output reg signed [31:0] acc_out
);

parameter DATA_WIDTH = 16;
parameter ACC_WIDTH = 32;
parameter FRAC_BITS = 8;

/*
Purpose: Q8.8 multiply-accumulate primitive.
Architecture: One registered multiplier plus accumulator, written as the
  canonical "acc <= acc_in + (a*b)" form so Synplify Pro (Libero SoC's
  synthesis engine) infers a single PolarFire Math/DSP block (PF_MACC) per
  instance instead of building the multiply in fabric LUTs. No fabric
  multiplier fallback is expected for this pattern; if the mapper report
  shows LUT-based multiplication, add an explicit PF_MACC instantiation
  here in place of the '*' operator.
Ports: data_in and weight are Q8.8; acc_in and acc_out are Q24.8 style 32-bit values.
Timing: One registered output cycle. PF_MACC hardware also owns an optional
  extra input/output pipeline register (not used here since this module is
  already single-cycle) that can be enabled via the PF_MACC "PIPELINED"
  configuration if this block is ever reused as a shared multi-cycle
  sequencer at a higher target frequency.
Pipeline stage: Arithmetic building block for convolution and dense layers.
Data flow: sample/feature and weight -> scaled product -> accumulator.
Algorithm: acc_out = acc_in + ((data_in * weight) >>> FRAC_BITS).
Expected latency: One clock.
Resource estimate: One PF_MACC (PolarFire Math block), no fabric LUT multiplier.
*/
always @(posedge clk) begin
    if (rst) begin
        valid_out <= 1'b0;
        acc_out <= {ACC_WIDTH{1'b0}};
    end else begin
        valid_out <= valid_in;
        if (valid_in) begin
            acc_out <= acc_in + ((data_in * weight) >>> FRAC_BITS);
        end
    end
end

endmodule
