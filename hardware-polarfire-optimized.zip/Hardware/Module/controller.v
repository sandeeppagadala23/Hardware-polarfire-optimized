module controller (
    input clk,
    input rst,
    input start,
    input input_valid,
    input window_valid,
    input conv_valid,
    input relu_valid,
    input pool_valid,
    input flatten_valid,
    input fc_valid,
    input class_valid,
    input output_ready,
    output reg input_enable,
    output reg window_enable,
    output reg conv_enable,
    output reg relu_enable,
    output reg pool_enable,
    output reg flatten_enable,
    output reg fc_enable,
    output reg classify_enable,
    output reg output_enable,
    output reg done,
    output reg [3:0] state
);

parameter IDLE = 4'd0;
parameter LOAD = 4'd1;
parameter WINDOW = 4'd2;
parameter CONV = 4'd3;
parameter RELU = 4'd4;
parameter POOL = 4'd5;
parameter FC = 4'd6;
parameter CLASSIFY = 4'd7;
parameter OUTPUT = 4'd8;
parameter DONE = 4'd9;

reg [3:0] next_state;

/*
Purpose: Supervisory FSM for the streaming ECG accelerator.
Architecture: Clean registered FSM with combinational next-state and stage-enable outputs.
Ports: valid inputs observe each pipeline stage; enable outputs expose current progress.
Timing: State updates synchronously on clk with active-high rst.
Pipeline stage: Global control and status.
Data flow: Tracks first frame through input, window, convolution, activation, pooling, FC, classify, output.
Algorithm: Advance through IDLE, LOAD, WINDOW, CONV, RELU, POOL, FC, CLASSIFY, OUTPUT, DONE.
Expected latency: Control-only; does not add datapath latency.
Resource estimate: One state register and simple decode gates.
PolarFire pipeline note: conv1d_engine.v and fully_connected.v were each
  extended from a 1-cycle to a 2-cycle pipeline to shorten the PolarFire
  fabric critical path (see those modules' headers). No change was needed
  here: this FSM advances CONV->RELU on conv_valid and FC->CLASSIFY on
  fc_valid directly, rather than counting a fixed number of clocks, so it
  transparently absorbs the extra pipeline stage in each of those states.
  This is the reason state was kept valid-driven rather than counter-driven
  in the original design, and it is the property that requirement (1) in
  the optimization brief ("thread valid/enable through controller.v so the
  FSM stays synchronized") relies on here.
*/
always @(*) begin
    next_state = state;
    input_enable = 1'b0;
    window_enable = 1'b0;
    conv_enable = 1'b0;
    relu_enable = 1'b0;
    pool_enable = 1'b0;
    flatten_enable = 1'b0;
    fc_enable = 1'b0;
    classify_enable = 1'b0;
    output_enable = 1'b0;
    done = 1'b0;

    case (state)
        IDLE: begin
            if (start) begin
                next_state = LOAD;
            end
        end
        LOAD: begin
            input_enable = 1'b1;
            if (input_valid) begin
                next_state = WINDOW;
            end
        end
        WINDOW: begin
            window_enable = 1'b1;
            if (window_valid) begin
                next_state = CONV;
            end
        end
        CONV: begin
            conv_enable = 1'b1;
            if (conv_valid) begin
                next_state = RELU;
            end
        end
        RELU: begin
            relu_enable = 1'b1;
            if (relu_valid) begin
                next_state = POOL;
            end
        end
        POOL: begin
            pool_enable = 1'b1;
            flatten_enable = 1'b1;
            if (pool_valid) begin
                next_state = FC;
            end
        end
        FC: begin
            fc_enable = 1'b1;
            if (flatten_valid) begin
                next_state = CLASSIFY;
            end
        end
        CLASSIFY: begin
            classify_enable = 1'b1;
            if (fc_valid) begin
                next_state = OUTPUT;
            end
        end
        OUTPUT: begin
            output_enable = 1'b1;
            if (output_ready) begin
                next_state = DONE;
            end
        end
        DONE: begin
            done = 1'b1;
            next_state = start ? LOAD : IDLE;
        end
        default: begin
            next_state = IDLE;
        end
    endcase
end

always @(posedge clk) begin
    if (rst) begin
        state <= IDLE;
    end else begin
        state <= next_state;
    end
end

endmodule
