module sliding_window_1d (
    input clk,
    input rst,
    input sample_valid,
    input signed [15:0] sample_in,
    output reg window_valid,
    output reg signed [79:0] window_out
);

parameter DATA_WIDTH = 16;
parameter KERNEL_SIZE = 5;

integer i;
reg [3:0] fill_count;

/*
Purpose: Converts the ECG sample stream into overlapping 1D convolution windows.
Architecture: Shift-register delay line with parameterized kernel length.
Ports: sample_valid/sample_in accept one ECG sample; window_out packs newest sample at index 0.
Timing: After KERNEL_SIZE samples, one window is emitted for each valid input.
Pipeline stage: Sliding-window generation.
Data flow: FIFO sample -> K-sample window -> conv1d_engine.
Algorithm: Shift previous samples up and insert the newest sample at window slice 0.
Expected latency: KERNEL_SIZE clocks to first valid window, then one window per sample.
Resource estimate: KERNEL_SIZE x DATA_WIDTH flip-flops.
*/
always @(posedge clk) begin
    if (rst) begin
        fill_count <= 4'd0;
        window_valid <= 1'b0;
        window_out <= {KERNEL_SIZE*DATA_WIDTH{1'b0}};
    end else begin
        window_valid <= 1'b0;
        if (sample_valid) begin
            for (i = KERNEL_SIZE-1; i > 0; i = i - 1) begin
                window_out[i*DATA_WIDTH +: DATA_WIDTH] <= window_out[(i-1)*DATA_WIDTH +: DATA_WIDTH];
            end
            window_out[0 +: DATA_WIDTH] <= sample_in;

            if (fill_count < KERNEL_SIZE) begin
                fill_count <= fill_count + 1'b1;
            end
            if (fill_count >= (KERNEL_SIZE - 1)) begin
                window_valid <= 1'b1;
            end
        end
    end
end

endmodule
