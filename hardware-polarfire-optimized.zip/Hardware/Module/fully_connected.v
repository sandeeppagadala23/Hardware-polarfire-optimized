module fully_connected (
    input clk,
    input rst,
    input valid_in,
    input signed [127:0] feature_vector,
    output reg valid_out,
    output reg signed [31:0] score_normal,
    output reg signed [31:0] score_arrhythmia
);

parameter DATA_WIDTH = 32;
parameter WEIGHT_WIDTH = 16;
parameter FEATURE_COUNT = 4;
parameter ACC_WIDTH = 32;
parameter FRAC_BITS = 8;
parameter WEIGHT_COUNT = 16;
parameter WEIGHT_BASE = 6;
parameter WEIGHTS_FILE = "weights.mem";

// PolarFire-friendly weight store: explicitly sized, single read port,
// loaded once via $readmemh. syn_romstyle guides Synplify Pro (Libero
// SoC's synthesis engine) toward a dedicated PolarFire uSRAM/LSRAM block
// rather than scattered fabric flip-flops once the table is large enough
// to be worth it -- same rationale as conv1d_engine.v.
(* syn_romstyle = "block_rom" *)
reg signed [WEIGHT_WIDTH-1:0] weights [0:WEIGHT_COUNT-1];

// Pipeline stage 1: one registered scaled product per feature, per class.
// Each (feature * weight) multiply is a standalone a*b pattern that
// Synplify maps to its own PF_MACC block; registering here uses the
// PF_MACC's own output register.
reg signed [ACC_WIDTH-1:0] product_normal_reg [0:FEATURE_COUNT-1];
reg signed [ACC_WIDTH-1:0] product_arr_reg [0:FEATURE_COUNT-1];
reg signed [ACC_WIDTH-1:0] bias_normal_reg;
reg signed [ACC_WIDTH-1:0] bias_arr_reg;
reg valid_stage1;
integer i;
integer j;

// Pipeline stage 2: combinational reduction (adders only) of the
// registered per-class products plus bias, registered once into the
// output scores. This is the critical-path win: the old design evaluated
// 2 x FEATURE_COUNT multiplies AND two 5-input add chains in a single
// combinational block ahead of the output register.
reg signed [ACC_WIDTH-1:0] sum_normal_comb;
reg signed [ACC_WIDTH-1:0] sum_arr_comb;

/*
Purpose: Binary dense layer for normal-vs-arrhythmia scoring.
Architecture: 2-stage pipelined MAC array, duplicated per class. Stage 1
  registers FEATURE_COUNT independent Q8.8 products per class (each
  inferred as a PolarFire PF_MACC block). Stage 2 registers the sum of
  those products plus bias through a short adder-only tree. Same
  pipelining strategy as conv1d_engine.v, applied to both class dot
  products in parallel.
Ports: feature_vector is packed pooled CNN data; outputs are signed class scores.
Timing: Two clocks from valid_in to valid_out (was one clock before this
  pipelining pass). Fully pipelined: a new valid_in can be accepted every
  clock, so throughput is unchanged -- only the fixed pipeline latency
  grew by one cycle.
Pipeline stage: Fully connected inference, stage 1 of 2 (multiply/register)
  then stage 2 of 2 (reduce/register).
Data flow: flatten -> fully_connected -> classifier.
Algorithm: score = bias + sum((feature[i] * class_weight[i]) >>> 8),
  weights from $readmemh. Grouping of the sum differs from the original
  single-step version but two's-complement addition modulo 2^32 is
  associative, so the registered result is bit-identical to the original
  combinational result.
Expected latency: Two clocks.
Resource estimate: 2 x FEATURE_COUNT PF_MACC-inferred multiply-accumulate
  blocks (stage 1, each with its own output register), two 5-input
  registered adders for bias + reduction, one per class (stage 2).
*/
initial begin
    $readmemh(WEIGHTS_FILE, weights);
end

// Stage 1: register the per-feature scaled products and both biases.
always @(posedge clk) begin
    if (rst) begin
        valid_stage1 <= 1'b0;
        bias_normal_reg <= {ACC_WIDTH{1'b0}};
        bias_arr_reg <= {ACC_WIDTH{1'b0}};
        for (i = 0; i < FEATURE_COUNT; i = i + 1) begin
            product_normal_reg[i] <= {ACC_WIDTH{1'b0}};
            product_arr_reg[i] <= {ACC_WIDTH{1'b0}};
        end
    end else begin
        valid_stage1 <= valid_in;
        if (valid_in) begin
            bias_normal_reg <= {{(ACC_WIDTH-WEIGHT_WIDTH){weights[WEIGHT_BASE+FEATURE_COUNT][WEIGHT_WIDTH-1]}}, weights[WEIGHT_BASE+FEATURE_COUNT]};
            bias_arr_reg <= {{(ACC_WIDTH-WEIGHT_WIDTH){weights[WEIGHT_BASE+(2*FEATURE_COUNT)+1][WEIGHT_WIDTH-1]}}, weights[WEIGHT_BASE+(2*FEATURE_COUNT)+1]};
            for (i = 0; i < FEATURE_COUNT; i = i + 1) begin
                product_normal_reg[i] <= (feature_vector[i*DATA_WIDTH +: DATA_WIDTH] * weights[WEIGHT_BASE+i]) >>> FRAC_BITS;
                product_arr_reg[i] <= (feature_vector[i*DATA_WIDTH +: DATA_WIDTH] * weights[WEIGHT_BASE+FEATURE_COUNT+1+i]) >>> FRAC_BITS;
            end
        end
    end
end

// Combinational stage-2 reduction: adders only, short critical path.
always @(*) begin
    sum_normal_comb = bias_normal_reg;
    sum_arr_comb = bias_arr_reg;
    for (j = 0; j < FEATURE_COUNT; j = j + 1) begin
        sum_normal_comb = sum_normal_comb + product_normal_reg[j];
        sum_arr_comb = sum_arr_comb + product_arr_reg[j];
    end
end

// Stage 2: register the reduced sums as the output scores.
always @(posedge clk) begin
    if (rst) begin
        valid_out <= 1'b0;
        score_normal <= {ACC_WIDTH{1'b0}};
        score_arrhythmia <= {ACC_WIDTH{1'b0}};
    end else begin
        valid_out <= valid_stage1;
        if (valid_stage1) begin
            score_normal <= sum_normal_comb;
            score_arrhythmia <= sum_arr_comb;
        end
    end
end

endmodule
