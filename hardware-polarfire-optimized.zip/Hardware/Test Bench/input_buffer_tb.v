module input_buffer_tb;

reg clk;
reg rst;
reg sample_valid;
reg sample_ready;
reg signed [15:0] sample_in;
wire sample_out_valid;
wire signed [15:0] sample_out;
wire full;
wire empty;
wire overflow;
integer errors;

input_buffer dut (
    .clk(clk),
    .rst(rst),
    .sample_valid(sample_valid),
    .sample_ready(sample_ready),
    .sample_in(sample_in),
    .sample_out_valid(sample_out_valid),
    .sample_out(sample_out),
    .full(full),
    .empty(empty),
    .overflow(overflow)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    sample_valid = 1'b0;
    sample_ready = 1'b0;
    sample_in = 16'sd0;
    errors = 0;
    #20 rst = 1'b0;

    #10 sample_in = 16'sh0100; sample_valid = 1'b1;
    #10 sample_in = 16'sh0120;
    #10 sample_valid = 1'b0;
    #10 sample_ready = 1'b1;
    #10;
    if (!sample_out_valid || sample_out != 16'sh0100) errors = errors + 1;
    #10;
    if (!sample_out_valid || sample_out != 16'sh0120 || !empty) errors = errors + 1;
    sample_ready = 1'b0;

    if (errors == 0) $display("input_buffer_tb PASS");
    else begin $display("input_buffer_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
