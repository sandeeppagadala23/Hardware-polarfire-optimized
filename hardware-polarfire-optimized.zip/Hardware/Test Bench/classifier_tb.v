module classifier_tb;

reg clk;
reg rst;
reg valid_in;
reg signed [31:0] score_normal;
reg signed [31:0] score_arrhythmia;
wire valid_out;
wire class_id;
wire signed [31:0] confidence;
integer errors;

classifier dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .score_normal(score_normal),
    .score_arrhythmia(score_arrhythmia),
    .valid_out(valid_out),
    .class_id(class_id),
    .confidence(confidence)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    score_normal = 32'sd0;
    score_arrhythmia = 32'sd0;
    errors = 0;
    #20 rst = 1'b0;
    #10 score_normal = 32'sd100; score_arrhythmia = 32'sd300; valid_in = 1'b1;
    #10 valid_in = 1'b0;
    #1;
    if (!valid_out || class_id != 1'b1 || confidence != 32'sd300) errors = errors + 1;
    if (errors == 0) $display("classifier_tb PASS");
    else begin $display("classifier_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
