module fully_connected_tb;

reg clk;
reg rst;
reg valid_in;
reg signed [127:0] feature_vector;
wire valid_out;
wire signed [31:0] score_normal;
wire signed [31:0] score_arrhythmia;
integer errors;

fully_connected dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .feature_vector(feature_vector),
    .valid_out(valid_out),
    .score_normal(score_normal),
    .score_arrhythmia(score_arrhythmia)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    feature_vector = 128'd0;
    errors = 0;
    #20 rst = 1'b0;
    #10;
    feature_vector[0 +: 32] = 32'sh00000100;
    feature_vector[32 +: 32] = 32'sh00000200;
    feature_vector[64 +: 32] = 32'sh00000300;
    feature_vector[96 +: 32] = 32'sh00000400;
    valid_in = 1'b1;
    #10 valid_in = 1'b0;
    // fully_connected.v is now a 2-cycle pipeline (PolarFire optimization pass:
    // stage 1 registers per-feature products, stage 2 registers the reduced
    // sums), so wait one extra clock edge before checking valid_out/scores.
    #10;
    #1;
    if (!valid_out) errors = errors + 1;
    if (score_normal != 32'sh00000A00) errors = errors + 1;
    if (score_arrhythmia != 32'sh00001500) errors = errors + 1;
    if (errors == 0) $display("fully_connected_tb PASS");
    else begin $display("fully_connected_tb FAIL errors=%0d normal=%0d arr=%0d", errors, score_normal, score_arrhythmia); $stop; end
    $finish;
end

endmodule
