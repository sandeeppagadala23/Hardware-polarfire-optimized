module conv1d_engine_tb;

reg clk;
reg rst;
reg window_valid;
reg signed [79:0] window_in;
wire conv_valid;
wire signed [31:0] conv_out;
integer errors;

conv1d_engine dut (
    .clk(clk),
    .rst(rst),
    .window_valid(window_valid),
    .window_in(window_in),
    .conv_valid(conv_valid),
    .conv_out(conv_out)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    window_valid = 1'b0;
    window_in = 80'd0;
    errors = 0;
    #20 rst = 1'b0;
    #10;
    window_in[0 +: 16] = 16'sh0500;
    window_in[16 +: 16] = 16'sh0400;
    window_in[32 +: 16] = 16'sh0300;
    window_in[48 +: 16] = 16'sh0200;
    window_in[64 +: 16] = 16'sh0100;
    window_valid = 1'b1;
    #10 window_valid = 1'b0;
    // conv1d_engine.v is now a 2-cycle pipeline (PolarFire optimization pass:
    // stage 1 registers products, stage 2 registers the reduced sum), so wait
    // one extra clock edge before checking conv_valid/conv_out.
    #10;
    #1;
    if (!conv_valid || conv_out != 32'sh00000300) errors = errors + 1;
    if (errors == 0) $display("conv1d_engine_tb PASS");
    else begin $display("conv1d_engine_tb FAIL errors=%0d conv_out=%0d", errors, conv_out); $stop; end
    $finish;
end

endmodule
