module sliding_window_1d_tb;

reg clk;
reg rst;
reg sample_valid;
reg signed [15:0] sample_in;
wire window_valid;
wire signed [79:0] window_out;
integer i;
integer errors;

sliding_window_1d dut (
    .clk(clk),
    .rst(rst),
    .sample_valid(sample_valid),
    .sample_in(sample_in),
    .window_valid(window_valid),
    .window_out(window_out)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    sample_valid = 1'b0;
    sample_in = 16'sd0;
    errors = 0;
    #20 rst = 1'b0;

    for (i = 1; i <= 5; i = i + 1) begin
        #10 sample_in = i * 16'sh0100; sample_valid = 1'b1;
    end
    #10 sample_valid = 1'b0;
    #1;
    if (!window_valid) errors = errors + 1;
    if (window_out[0 +: 16] != 16'sh0500) errors = errors + 1;
    if (window_out[64 +: 16] != 16'sh0100) errors = errors + 1;

    if (errors == 0) $display("sliding_window_1d_tb PASS");
    else begin $display("sliding_window_1d_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
