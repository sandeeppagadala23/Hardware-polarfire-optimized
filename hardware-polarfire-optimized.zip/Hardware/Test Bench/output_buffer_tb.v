module output_buffer_tb;

reg clk;
reg rst;
reg valid_in;
reg output_ready;
reg class_in;
reg signed [31:0] confidence_in;
wire valid_out;
wire class_out;
wire signed [31:0] confidence_out;
integer errors;

output_buffer dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .output_ready(output_ready),
    .class_in(class_in),
    .confidence_in(confidence_in),
    .valid_out(valid_out),
    .class_out(class_out),
    .confidence_out(confidence_out)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    output_ready = 1'b0;
    class_in = 1'b0;
    confidence_in = 32'sd0;
    errors = 0;
    #20 rst = 1'b0;
    #10 class_in = 1'b1; confidence_in = 32'sd333; valid_in = 1'b1;
    #10 valid_in = 1'b0;
    #1;
    if (!valid_out || !class_out || confidence_out != 32'sd333) errors = errors + 1;
    #9 output_ready = 1'b1;
    #10 output_ready = 1'b0;
    #1;
    if (valid_out) errors = errors + 1;
    if (errors == 0) $display("output_buffer_tb PASS");
    else begin $display("output_buffer_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
