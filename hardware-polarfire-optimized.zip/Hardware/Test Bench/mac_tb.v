module mac_tb;

reg clk;
reg rst;
reg valid_in;
reg signed [15:0] data_in;
reg signed [15:0] weight;
reg signed [31:0] acc_in;
wire valid_out;
wire signed [31:0] acc_out;
integer errors;

mac dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .data_in(data_in),
    .weight(weight),
    .acc_in(acc_in),
    .valid_out(valid_out),
    .acc_out(acc_out)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    data_in = 16'sd0;
    weight = 16'sd0;
    acc_in = 32'sd0;
    errors = 0;
    #20 rst = 1'b0;
    #10 data_in = 16'sh0200; weight = 16'sh0180; acc_in = 32'sh00000100; valid_in = 1'b1;
    #10 valid_in = 1'b0;
    #1;
    if (!valid_out || acc_out != 32'sh00000400) errors = errors + 1;
    if (errors == 0) $display("mac_tb PASS");
    else begin $display("mac_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
