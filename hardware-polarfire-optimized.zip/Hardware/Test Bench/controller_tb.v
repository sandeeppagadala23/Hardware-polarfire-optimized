module controller_tb;

reg clk;
reg rst;
reg start;
reg input_valid;
reg window_valid;
reg conv_valid;
reg relu_valid;
reg pool_valid;
reg flatten_valid;
reg fc_valid;
reg class_valid;
reg output_ready;
wire input_enable;
wire window_enable;
wire conv_enable;
wire relu_enable;
wire pool_enable;
wire flatten_enable;
wire fc_enable;
wire classify_enable;
wire output_enable;
wire done;
wire [3:0] state;
integer errors;

controller dut (
    .clk(clk),
    .rst(rst),
    .start(start),
    .input_valid(input_valid),
    .window_valid(window_valid),
    .conv_valid(conv_valid),
    .relu_valid(relu_valid),
    .pool_valid(pool_valid),
    .flatten_valid(flatten_valid),
    .fc_valid(fc_valid),
    .class_valid(class_valid),
    .output_ready(output_ready),
    .input_enable(input_enable),
    .window_enable(window_enable),
    .conv_enable(conv_enable),
    .relu_enable(relu_enable),
    .pool_enable(pool_enable),
    .flatten_enable(flatten_enable),
    .fc_enable(fc_enable),
    .classify_enable(classify_enable),
    .output_enable(output_enable),
    .done(done),
    .state(state)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    start = 1'b0;
    input_valid = 1'b0;
    window_valid = 1'b0;
    conv_valid = 1'b0;
    relu_valid = 1'b0;
    pool_valid = 1'b0;
    flatten_valid = 1'b0;
    fc_valid = 1'b0;
    class_valid = 1'b0;
    output_ready = 1'b0;
    errors = 0;
    #20 rst = 1'b0;
    #10 start = 1'b1;
    #10 start = 1'b0; input_valid = 1'b1;
    #10 input_valid = 1'b0; window_valid = 1'b1;
    #10 window_valid = 1'b0; conv_valid = 1'b1;
    #10 conv_valid = 1'b0; relu_valid = 1'b1;
    #10 relu_valid = 1'b0; pool_valid = 1'b1;
    #10 pool_valid = 1'b0; flatten_valid = 1'b1;
    #10 flatten_valid = 1'b0; fc_valid = 1'b1;
    #10 fc_valid = 1'b0; class_valid = 1'b1; output_ready = 1'b1;
    #20;
    if (!done && state != 4'd0) errors = errors + 1;
    if (errors == 0) $display("controller_tb PASS");
    else begin $display("controller_tb FAIL errors=%0d state=%0d", errors, state); $stop; end
    $finish;
end

endmodule
