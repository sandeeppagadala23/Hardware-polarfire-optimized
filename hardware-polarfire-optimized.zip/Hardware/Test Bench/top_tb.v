module top_tb;

reg clk;
reg rst;
reg start;
reg ecg_valid;
reg signed [15:0] ecg_sample;
reg output_ready;
wire output_valid;
wire class_out;
wire signed [31:0] confidence_out;
wire fifo_full;
wire done;
integer i;
integer errors;

top dut (
    .clk(clk),
    .rst(rst),
    .start(start),
    .ecg_valid(ecg_valid),
    .ecg_sample(ecg_sample),
    .output_ready(output_ready),
    .output_valid(output_valid),
    .class_out(class_out),
    .confidence_out(confidence_out),
    .fifo_full(fifo_full),
    .done(done)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    start = 1'b0;
    ecg_valid = 1'b0;
    ecg_sample = 16'sd0;
    output_ready = 1'b0;
    errors = 0;
    #20 rst = 1'b0;
    #10 start = 1'b1;

    for (i = 0; i < 32; i = i + 1) begin
        #10 ecg_valid = 1'b1;
        if ((i % 8) == 0) ecg_sample = 16'sh0280;
        else if ((i % 8) == 1) ecg_sample = 16'sh0100;
        else if ((i % 8) == 2) ecg_sample = 16'sh0080;
        else if ((i % 8) == 3) ecg_sample = -16'sh0040;
        else if ((i % 8) == 4) ecg_sample = -16'sh0080;
        else if ((i % 8) == 5) ecg_sample = 16'sh0000;
        else if ((i % 8) == 6) ecg_sample = 16'sh00C0;
        else ecg_sample = 16'sh0180;
    end
    #10 ecg_valid = 1'b0;

    for (i = 0; i < 80; i = i + 1) begin
        #10;
        if (output_valid) i = 80;
    end
    if (!output_valid) errors = errors + 1;
    if (class_out != 1'b1) errors = errors + 1;
    output_ready = 1'b1;
    #20 output_ready = 1'b0;

    if (errors == 0) $display("top_tb PASS class=%0d confidence=%0d", class_out, confidence_out);
    else begin $display("top_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
