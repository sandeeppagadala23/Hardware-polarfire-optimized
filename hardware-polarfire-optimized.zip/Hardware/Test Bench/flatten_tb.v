module flatten_tb;

reg clk;
reg rst;
reg valid_in;
reg signed [31:0] data_in;
wire valid_out;
wire signed [127:0] feature_vector;
integer i;
integer errors;

flatten dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .data_in(data_in),
    .valid_out(valid_out),
    .feature_vector(feature_vector)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    data_in = 32'sd0;
    errors = 0;
    #20 rst = 1'b0;
    for (i = 1; i <= 4; i = i + 1) begin
        #10 data_in = i * 32'sh00000100; valid_in = 1'b1;
    end
    #10 valid_in = 1'b0;
    #1;
    if (!valid_out) errors = errors + 1;
    if (feature_vector[0 +: 32] != 32'sh00000100) errors = errors + 1;
    if (feature_vector[96 +: 32] != 32'sh00000400) errors = errors + 1;
    if (errors == 0) $display("flatten_tb PASS");
    else begin $display("flatten_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
