module maxpool1d_tb;

reg clk;
reg rst;
reg valid_in;
reg signed [31:0] data_in;
wire valid_out;
wire signed [31:0] data_out;
integer errors;

maxpool1d dut (
    .clk(clk),
    .rst(rst),
    .valid_in(valid_in),
    .data_in(data_in),
    .valid_out(valid_out),
    .data_out(data_out)
);

always #5 clk = ~clk;

initial begin
    clk = 1'b0;
    rst = 1'b1;
    valid_in = 1'b0;
    data_in = 32'sd0;
    errors = 0;
    #20 rst = 1'b0;
    #10 data_in = 32'sh00000100; valid_in = 1'b1;
    #10 data_in = 32'sh00000300;
    #10;
    if (!valid_out || data_out != 32'sh00000300) errors = errors + 1;
    data_in = 32'sh00000200;
    #10 data_in = 32'sh00000180;
    #10;
    if (!valid_out || data_out != 32'sh00000200) errors = errors + 1;
    valid_in = 1'b0;
    if (errors == 0) $display("maxpool1d_tb PASS");
    else begin $display("maxpool1d_tb FAIL errors=%0d", errors); $stop; end
    $finish;
end

endmodule
