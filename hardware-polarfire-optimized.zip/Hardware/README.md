# ECG 1D CNN Streaming Accelerator

This folder contains a Verilog-only conversion of the original 2D image-processing CNN skeleton into an ECG 1D CNN streaming accelerator for binary arrhythmia detection.

## PolarFire SoC Optimization Pass

This design has been optimized for deployment on Microchip PolarFire SoC (PolarFire fabric + RISC-V MSS), targeting Libero SoC rather than Vivado. Summary of what changed:

- `mac.v`, `conv1d_engine.v`, `fully_connected.v`: multiply patterns kept/restructured as simple `a*b` and `a+b` forms so Synplify Pro (Libero's synthesis engine) infers PolarFire Math/DSP blocks (`PF_MACC`) instead of fabric LUT-based multipliers.
- `conv1d_engine.v` and `fully_connected.v`: the single-cycle combinational "multiply-then-add-tree" critical path was split into a 2-stage pipeline (register the products, then register the reduced sum). This is the actual timing fix — see Latency Analysis and FPGA Optimization Notes below.
- `weights.mem` loading: weight arrays are now explicitly sized `reg` arrays with a `syn_romstyle` attribute so Synplify can map them to PolarFire µSRAM/LSRAM once they're large enough to be worth it; `WEIGHTS_FILE` stays a parameter so Libero's simulation and synthesis flows (which may resolve relative paths differently than Vivado did) can override it.
- `top_axi_wrapper.v` (new file): a thin AXI4-Lite (control/status) + AXI4-Stream (ECG in / classification out) wrapper around the unmodified `top` module, for MSS integration. Includes an explicit clock-domain-crossing note for when the MSS AXI clock differs from the fabric `clk`.
- `constraints/top.sdc` (new file): Libero SoC timing constraints, target `clk` = 150 MHz.
- `controller.v` and `top.v`: no functional changes. `controller.v`'s FSM is valid-driven (waits on each stage's `*_valid`, not a fixed cycle count), so it already stays synchronized with the deeper conv1d/FC pipelines without modification — see the updated header comment in `controller.v` for why this satisfies the "keep the FSM synchronized" requirement without new logic.

See the change-summary table at the end of this document for the full per-module breakdown.

## Updated Folder Structure

```text
outputs/
  input_buffer.v
  input_buffer_tb.v
  sliding_window_1d.v
  sliding_window_1d_tb.v
  mac.v
  mac_tb.v
  conv1d_engine.v
  conv1d_engine_tb.v
  relu.v
  relu_tb.v
  maxpool1d.v
  maxpool1d_tb.v
  flatten.v
  flatten_tb.v
  fully_connected.v
  fully_connected_tb.v
  classifier.v
  classifier_tb.v
  controller.v
  controller_tb.v
  output_buffer.v
  output_buffer_tb.v
  top.v
  top_tb.v
  weights.mem
  README.md
```

## Reuse And Replacement Summary

Reusable modules retained in ECG form: `input_buffer.v`, `mac.v`, `relu.v`, `fully_connected.v`, `classifier.v`, `controller.v`, `output_buffer.v`.

Image-specific modules replaced: `line_buffer.v` became `sliding_window_1d.v`, `convolution.v` became `conv1d_engine.v`, and `pooling.v` became `maxpool1d.v`.

New module added: `flatten.v`.

## Block Diagram

```text
16-bit Q8.8 ECG samples
        |
        v
+----------------+
| input_buffer   |
+----------------+
        |
        v
+-------------------+
| sliding_window_1d |
| kernel size = 5   |
+-------------------+
        |
        v
+---------------------------+
| conv1d_engine             |
| weights.mem               |
| stage1: reg products      |
|   (PF_MACC inferred)      |
| stage2: reg reduced sum   |
+---------------------------+
        |
        v
+----------------+
| relu           |
+----------------+
        |
        v
+----------------+
| maxpool1d      |
| pool size = 2  |
+----------------+
        |
        v
+----------------+
| flatten        |
+----------------+
        |
        v
+---------------------------+
| fully_connected            |
| weights.mem                |
| stage1: reg products       |
|   (PF_MACC inferred)       |
| stage2: reg reduced sums   |
+---------------------------+
        |
        v
+----------------+
| classifier     |
| 0 normal       |
| 1 arrhythmia   |
+----------------+
        |
        v
+----------------+
| output_buffer  |
+----------------+
```

## Dataflow Diagram

```text
ecg_valid/ecg_sample
  -> FIFO write
  -> FIFO read when start is high
  -> K-sample sliding window
  -> Q8.8 convolution dot product
  -> ReLU clamp
  -> non-overlapping 1D max pool
  -> four pooled features packed into one vector
  -> two fully-connected class scores
  -> binary comparator
  -> held result until output_ready
```

## FSM Diagram

```text
IDLE
  |
  | start
  v
LOAD -> WINDOW -> CONV -> RELU -> POOL -> FC -> CLASSIFY -> OUTPUT -> DONE
  ^                                                                  |
  |------------------------------------------------------------------|
```

The datapath is streaming and does not wait for the FSM to enable each block. The controller provides clean status and stage-enable outputs for integration, debugging, and future clock-enable gating.

## Weights

`weights.mem` is loaded with `$readmemh()` by both `conv1d_engine.v` and `fully_connected.v`.

Current memory map:

```text
0..4    conv1d weights
5       conv1d bias
6..9    fully connected normal weights
10      normal bias
11..14  fully connected arrhythmia weights
15      arrhythmia bias
```

Values are signed hexadecimal Q8.8 entries. For example, `0100` means `+1.0`, `0200` means `+2.0`, and `FF00` means `-1.0`.

## Integration Guide

Instantiate `top.v` with these primary ports:

```verilog
top u_top (
    .clk(clk),
    .rst(rst),
    .start(start),
    .ecg_valid(ecg_valid),
    .ecg_sample(ecg_sample),
    .output_ready(output_ready),
    .output_valid(output_valid),
    .class_out(class_out),
    .confidence_out(confidence_out),
    .fifo_full(fifo_full),
    .done(done)
);
```

Drive `ecg_sample` as signed 16-bit Q8.8 ECG data. Keep `start` high during streaming operation. Assert `output_ready` for one or more clocks to consume a classification result.

## Vivado Simulation Guide

1. Create an RTL project.
2. Add all `.v` files as design sources except files ending in `_tb.v`.
3. Add all `_tb.v` files as simulation sources.
4. Add `weights.mem` as a simulation memory file in the simulation run directory.
5. Set the desired testbench as top, for example `top_tb`.
6. Run behavioral simulation and look for `PASS`.

## Vivado Synthesis Guide

1. Add RTL files only: `input_buffer.v`, `sliding_window_1d.v`, `mac.v`, `conv1d_engine.v`, `relu.v`, `maxpool1d.v`, `flatten.v`, `fully_connected.v`, `classifier.v`, `controller.v`, `output_buffer.v`, and `top.v`.
2. Add `weights.mem` to the project so `$readmemh()` can initialize inferred ROM content.
3. Set `top` as the synthesis top.
4. Constrain `clk` for the target ECG sample processing rate.
5. Synthesize and inspect inferred multipliers, RAM, and timing paths.

## Simulation Results Expected

Each standalone testbench prints `PASS` when its self-checks complete. The top-level testbench feeds a realistic pulse-like ECG sample stream and expects an arrhythmia classification because the demo arrhythmia FC weights are intentionally larger.

## Timing Considerations

The longest paths were in `conv1d_engine.v` and `fully_connected.v`, where multiple multipliers and adders were evaluated before a single output register. As of the PolarFire optimization pass, both modules now register the per-tap products (stage 1) separately from the reduced sum (stage 2), so the remaining combinational path per stage is either a single PF_MACC-inferred multiply or a short adder-only tree, not both in series. See `constraints/top.sdc` for the resulting target `clk` and the timing budget reasoning; re-verify with Libero SmartTime after synthesis and place-and-route, since the estimate there is a starting point, not a closure guarantee.

## Latency Analysis

Default first-output latency is approximately:

```text
input FIFO read         1 clock
sliding window fill     5 valid samples
conv1d                  2 clocks  (was 1 -- now a 2-stage PolarFire-optimized pipeline)
relu                    1 clock
maxpool1d               2 valid conv results
flatten                 4 pooled results
fully connected         2 clocks  (was 1 -- now a 2-stage PolarFire-optimized pipeline)
classifier              1 clock
output buffer           1 clock
```

With continuous valid samples, the first frame appears after roughly 19 clocks from the start of FIFO draining (was 17 clocks before the PolarFire optimization pass). Exact latency depends on FIFO occupancy and `output_ready`. The two added clocks come from splitting `conv1d_engine.v`'s and `fully_connected.v`'s combinational multiply+add-tree into a registered 2-stage pipeline (see FPGA Optimization Notes below) -- this is a one-time fixed-latency cost, not a recurring one, since both stages are fully pipelined.

## Throughput Analysis

After the pipeline fills, `sliding_window_1d` and `conv1d_engine` can accept one ECG sample per clock. With default `POOL_SIZE = 2` and `FEATURE_COUNT = 4`, the default top emits one classification per eight post-fill convolution windows.

Splitting `conv1d_engine.v` and `fully_connected.v` into 2-stage pipelines (PolarFire optimization pass) added fixed latency only -- both stages accept a new input every clock, so steady-state throughput is unchanged at one convolution window per clock and one classification per eight post-fill windows.

## FPGA Optimization Suggestions

Applied in this pass, PolarFire-specific:
- `mac.v`, `conv1d_engine.v`, `fully_connected.v` use plain `a*b`/`a+b` patterns so Synplify Pro infers PolarFire Math/DSP (`PF_MACC`) blocks instead of fabric LUT multipliers.
- `conv1d_engine.v` and `fully_connected.v` now pipeline the multiply and reduce steps into two registered stages (see Timing Considerations) instead of one large combinational block, for PolarFire fabric timing closure at the target `clk` in `constraints/top.sdc`.
- Weight arrays carry a `syn_romstyle` attribute to steer Synplify toward PolarFire µSRAM/LSRAM once a table is large enough to be worth mapping off of fabric flip-flops.

Still open for a future pass: infer distributed RAM or LSRAM for a deeper `input_buffer.v` FIFO if burst sizes grow past the current `DEPTH = 32`.

## Resource Optimization Suggestions

For small devices, replace parallel multiply trees with a shared multi-cycle `mac.v` sequencer. For higher throughput, keep the parallel, pipelined architecture used here.

## Power Optimization Suggestions

Gate stage work with valid signals, keep `start` low when monitoring is inactive, reduce FIFO depth to the minimum needed for burst absorption, and quantize trained weights to the smallest acceptable fixed-point width.

## Libero SoC Simulation Guide

1. Create a Libero SoC project targeting the PolarFire SoC device/die you're deploying to.
2. Add all `.v` files under `Module/` (including `top_axi_wrapper.v` if using AXI integration) as design source files.
3. Add all `_tb.v` files under `Test Bench/` as stimulus/testbench files for QuestaSim/ModelSim (Libero's bundled simulator).
4. Make sure `weights.mem` is on the simulator's working-directory/search path Libero uses for `$readmemh` -- this differs from a Vivado simulation working directory, so verify it resolves before trusting `PASS` output. If it doesn't resolve, override each instance's `WEIGHTS_FILE` parameter with an absolute path.
5. Set the desired testbench (e.g. `top_tb`) as the simulation top and run; look for `PASS` from each testbench, same pass/fail convention as before.

## Libero SoC Synthesis Guide

1. Add RTL files only (no `_tb.v` files) as synthesis sources: `input_buffer.v`, `sliding_window_1d.v`, `mac.v`, `conv1d_engine.v`, `relu.v`, `maxpool1d.v`, `flatten.v`, `fully_connected.v`, `classifier.v`, `controller.v`, `output_buffer.v`, `top.v`, and `top_axi_wrapper.v` if integrating with the MSS over AXI.
2. Add `weights.mem` to the project so `$readmemh()` can initialize the PolarFire-mapped weight storage at bitstream generation.
3. Add `constraints/top.sdc` as the SDC constraint file.
4. Set `top` (standalone) or `top_axi_wrapper` (MSS-integrated) as the synthesis top, matching your integration choice.
5. Synthesize with Synplify Pro and confirm in the mapper report that multipliers were inferred as `PF_MACC` and not fabric logic; run SmartTime and re-tune `constraints/top.sdc` if the target `clk` isn't met.

## MSS Integration (AXI4 Wrapper)

`top_axi_wrapper.v` wraps the unmodified `top` module with:
- An AXI4-Lite slave exposing a CONTROL register (`start`, `output_ready`) and a STATUS register (`done`, `fifo_full`, `output_valid`, `class_out`).
- An AXI4-Stream slave (`s_axis_*`) feeding ECG samples in, backpressured by the existing `input_buffer.v` FIFO's `fifo_full`.
- An AXI4-Stream master (`m_axis_*`) emitting the packed classification result (`class_out` + `confidence_out`) as one 64-bit beat.

This is a sketch for MSS integration, not a drop-in verified IP block -- see the clock-domain-crossing note in `top_axi_wrapper.v`'s header before using it with an MSS AXI clock that differs from the fabric `clk` driving `top`.

## Change Summary

| Module | What changed | Why | Resource/timing impact |
|---|---|---|---|
| `mac.v` | No logic change; header documents that the existing `acc_in + (a*b)` pattern already infers a PolarFire `PF_MACC` block. | Requirement 2 asks to confirm DSP inference, not necessarily restructure code that already fits the pattern. | None (same one `PF_MACC` per instance, same 1-cycle latency). |
| `conv1d_engine.v` | Split the single combinational "5 multiplies + 6-input add" block into a 2-stage pipeline: stage 1 registers each scaled product (PF_MACC-inferred), stage 2 registers the adder-only reduced sum. Weight array gained an explicit `syn_romstyle` attribute. | Shortens the PolarFire fabric critical path (README's own Timing Considerations flagged this block). | Latency window_valid->conv_valid: 1 clock -> 2 clocks. Throughput unchanged (1 window/clock, fully pipelined). Same PF_MACC count; adder tree now registered instead of purely combinational. |
| `fully_connected.v` | Same 2-stage pipelining strategy applied to both the normal and arrhythmia dot products in parallel. Weight array gained `syn_romstyle`. | Same critical-path reason as `conv1d_engine.v`. | Latency valid_in->valid_out: 1 clock -> 2 clocks. Throughput unchanged. Same PF_MACC count (2 x FEATURE_COUNT), adder trees now registered. |
| `controller.v` | No logic change; header comment explains why none was needed. | FSM is valid-driven (waits on each stage's `*_valid`), so it already tolerates the deeper conv1d/FC pipelines. | None -- state machine correctness preserved automatically. |
| `top.v` | No port/instantiation changes; header comment latency/resource estimates updated (17 -> 19 clocks; multipliers now called out as `PF_MACC`). | Keep the top-level doc accurate after the pipelining change. | Documentation only. |
| `top_axi_wrapper.v` | New file. AXI4-Lite control/status + AXI4-Stream sample-in/result-out wrapper around unmodified `top`. | Requirement 2's MSS integration ask; keeps `top.v` reusable standalone. | Adds an AXI4-Lite/Stream shim with no added pipeline latency to the wrapped core; CDC handling flagged as a TODO for multi-clock designs. |
| `constraints/top.sdc` | New file. `create_clock` at 150 MHz, I/O delay budget, false path on `rst`, notes on `weights.mem` path resolution and future multi-clock constraints. | Requirement 2's Libero SDC deliverable. | Enables Libero synthesis/SmartTime closure checks; target frequency is an estimate to be re-verified post place-and-route. |
| `conv1d_engine_tb.v` | Added one extra clock-edge wait before checking `conv_valid`/`conv_out`. | Match the new 2-cycle pipeline latency. | Test intent unchanged; same expected `conv_out` value (sum is associative under mod-2^32 addition, so results are bit-identical). |
| `fully_connected_tb.v` | Added one extra clock-edge wait before checking `valid_out`/scores. | Match the new 2-cycle pipeline latency. | Test intent unchanged; same expected `score_normal`/`score_arrhythmia` values. |
| `top_tb.v` | No change needed. | It already polls `output_valid` for up to 80 clocks rather than assuming a fixed latency, so it absorbs the +2 clock change automatically. | None. |
| `README.md` | Block diagram, latency analysis, throughput analysis, timing considerations, FPGA optimization suggestions updated; Libero SoC simulation/synthesis guides and this change table added. | Requirement 3: keep docs matching the RTL exactly. | Documentation only. |

## Notes

All RTL and testbenches are pure Verilog-style `.v` files. No VHDL, SystemVerilog-only constructs, vendor primitives beyond the PolarFire Math/SRAM synthesis attributes called out above, HLS, or generated IP wrappers are used.
