# top.sdc
# Libero SoC (Synplify Pro synthesis + SmartTime) timing constraints for
# the ECG 1D-CNN streaming accelerator, PolarFire SoC target.
#
# Target clk: 150 MHz (period 6.667 ns).
# Rough budget: after the conv1d_engine.v / fully_connected.v pipelining
# pass, the remaining combinational reduction is a KERNEL_SIZE/FEATURE_COUNT
# -wide 32-bit adder tree only (no multiplies -- those are isolated inside
# PF_MACC blocks with their own output register). A 5-6 input 32-bit
# registered adder tree in PolarFire fabric is comfortably inside a 6.67 ns
# budget once routing margin is reserved; PF_MACC blocks themselves close
# well above 300 MHz on PolarFire, so they are not the limiter here.
# TREAT THIS AS A STARTING POINT: re-run SmartTime after synthesis/place-
# and-route and tighten or relax create_clock below to match the actual
# critical path report.

create_clock -name {clk} -period 6.667 -waveform {0 3.333} [get_ports {clk}]

# Asynchronous/system reset: treat as a false path for setup/hold, but make
# sure it is still brought through a synchronizer / CoreResetP in the real
# top-level so its release is synchronous to clk (see top_axi_wrapper.v
# CDC note for the multi-clock case).
set_false_path -from [get_ports {rst}]

# ECG sample input timing budget (assuming a moderate off-chip or MSS-side
# source; tighten once the real driving logic/interconnect is known).
set_input_delay -clock {clk} -max 2.000 [get_ports {ecg_valid ecg_sample[*] start output_ready}]
set_input_delay -clock {clk} -min 0.500 [get_ports {ecg_valid ecg_sample[*] start output_ready}]

set_output_delay -clock {clk} -max 2.000 [get_ports {output_valid class_out confidence_out[*] fifo_full done}]
set_output_delay -clock {clk} -min 0.500 [get_ports {output_valid class_out confidence_out[*] fifo_full done}]

# weights.mem is loaded once at elaboration (simulation) / bitstream
# generation (synthesis) via $readmemh inside conv1d_engine.v and
# fully_connected.v -- no additional memory-init constraint is needed here,
# but keep weights.mem on the Libero project's include/search path so both
# simulation (ModelSim/QuestaSim launched from Libero) and synthesis
# (Synplify Pro) resolve the relative path the same way. If Libero's
# working directory differs between the two flows, override WEIGHTS_FILE
# per-instance in top.v (or top_axi_wrapper.v) with an absolute path, e.g.:
#   conv1d_engine #(.WEIGHTS_FILE("/abs/path/to/weights.mem")) u_conv1d_engine (...);

# If a future revision drives top_axi_wrapper.v's AXI4-Lite/AXI4-Stream
# ports from a separate MSS-domain clock, add a second create_clock for
# that domain and set_clock_groups -asynchronous between the two, then
# replace the single-clock assumption in top_axi_wrapper.v's CDC note with
# a real CoreAXI4 stream FIFO / synchronizer per that note.
